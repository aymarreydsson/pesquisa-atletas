dados.forEach(function(atleta) {
    console.log("Título: " + atleta.titulo);
    console.log("Descrição: " + atleta.descricao);
    console.log("Link: " + atleta.link);
    console.log("------------------------");
    });
function pesquisar() {
   // obtém a seção HTML onde os resultados serão exibidos
    let section = document.getElementById("resultados-pesquisa");

    //Inicializa uma String vazia para armazenar os resultados
    let resultados = "";
    let titulo ="";
    let descrição = "";
    let tags = "";

    //Itera sobre cada dado da lista de dados 
    for (let dado of dados) {
        titulo = dado.titulo.toLowerCase();
        descrição = dado.descrição.toLowerCase();
        tags = dado.tags.toLowerCase();
        // se titulo includes campoPesquisa
        if (titulo.includes(campoPesquisa) || descrição.includes(capoPesquisa) || tags.includes (campoPesquisa) ){
        // Cria um novo elemento HTML para cada resultado
        resultados += `
        <div clas= "item resultado">
            <h2>
            <a href="#" target="_blank">${dado.titulo}<a/>
            </h2>
            <p class="descrição-meta">${dado.descrição}</p>
            <a href=${dado.link} target=" _blank">Mais informações</a>
        </div>
        `;
        }
    }

    if (!resultados){
        resultados = "<p>Nada foi encontrado</p>"
    }

    //Atribui os resultados gerados à seção HTML
    section.innerHTML = resultados;
}
     function pesquisar() {
        //Obtém s seção HTML onde os resultados serão exibidos
        let section = document.getElementById("reultados-pesquisa");

        // Inicializa uma string vazia para armazenar os resultados 
        let resultados = "";

        // Itera sobre cada dado da lista de dados 
        for (let dado of dados) {
             // Cria um novo elemento HTML para cada resultado
             resultados += `
                <div class= "item-resultados">
                    <h2>
                         <a href="#" target="_blank">${dado.titulo}</a>
                         </h2>
                         <p class="descrição-meta">${dado.descricão}</p>
                         <a href=${dado.link} target="_blank">Mais informações</a>
                         </div>
                    `;

        }

        // Atribui os resultados gerados à seção HTML
        section.innerHTML =resultados;
     }